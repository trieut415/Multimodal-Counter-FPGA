# EC311_Lab2_Template

Use the top files "debouncer.v" and "seven_segment_display_counter.v" in the hdl folders in the part1 and part2 folders as top files for the corresponding parts for lab-2.

Submit your tb files in the tb folder
